
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

class student {
	int idnum;
	char name[50];
	long int inft154, comp152, inft152, comp164, uenr102;
	double per;
	char grade;

public:
	void calculate();
	void getdata();
	void showdata() const;
	void show_tablular() const;
	int getIDnum() const;
};

void student::calculate() {
	per = (inft154 + comp152 + inft152 + comp164 + uenr102) / 5.0;
	if (per >= 80.00 && per <= 100)
		grade = 'A';
	else if (per >= 70.00 && per <= 79.00)
		grade = 'B';
	else if (per >= 60.00 && per <= 69.00)
		grade = 'C';
	else if (per >= 50.00 && per <= 59.00)
		grade = 'D';
	else if (per >= 40.00 && per <= 49.00)
		grade = 'E';
	else
		grade = 'F';
}

void student::getdata() {
	cout << "\n\tEnter the ID number of Student: ";
	cin >> idnum;
	cout << "\n\tEnter Student Name: ";
	cin.ignore();
	cin.getline(name, 50);
	cout << "\n\tEnter Student Information Theory Grade: ";
	cin >> inft154;
	cout << "\n\tEnter Student C++ Programming Grade: ";
	cin >> comp152;
	cout << "\n\tEnter Student Computer Ethics Grade: ";
	cin >> inft152;
	cout << "\n\tEnter Student Basic Electronics Grade: ";
	cin >> comp164;
	cout << "\n\tEnter Student Com Skills Grade: ";
	cin >> uenr102;
	calculate();

}

void student::showdata() const {
	cout << "\n\tID Number: " << idnum;
	cout << "\n\tName: "<<name;
	cout << "\n\tInformation Theory: " << inft154;
	cout << "\n\tC++ Programming: " << comp152;
	cout << "\n\tComputer Ethics: " << inft152;
	cout << "\n\tBasic Electronics: " << comp164;
	cout << "\n\tSkills: " << uenr102;
	cout << "\n\tPercentage: " << per;
	cout << "\n\tGrade Letter: " << grade;

}

void student::show_tablular() const {
	cout << idnum << setw(6) << " " << name << setw(10) << inft154 << setw(4) << comp152 << setw(4) << inft152 << setw(4) << comp164 << setw(4) << uenr102 << setw(8) << per << setw(6) << grade << endl;

}

int student::getIDnum() const {
	return idnum;
}

void SaveStudent();
void displayAll();
void Searchdisplay(int);
void modifyStudent(int);
void deleteStudent(int);
void DisplayClassResult();
void DisplayResult();

void write_student() {
	student st;
	ofstream outFile;
	outFile.open("student.dat", ios::binary|ios::app);
	st.getdata();
	outFile.write(reinterpret_cast<char*>(&st), sizeof(student));
	outFile.close();
	cout << "\n\nStudent record has been created ";
	cin.ignore();
	cin.get();
}

void display_all() {
	student st;
	ifstream inFile;
	inFile.open("student.dat", ios::binary);
	if (!inFile) {
		cout << "File could not be opened!! Press Enter...";
		cin.ignore();
		cin.get();
		return;
	}
	cout << "\n\n\n\t\tDISPLAY ALL RECORD !!!\n\n";
	while (inFile.read(reinterpret_cast<char*>(&st), sizeof(student)))
	{
		st.showdata();
		cout << "\n\n********************************************\n";
	}
	inFile.close();
	cin.ignore();
	cin.get();
}

void display_sp(int n) {
	student st;
	ifstream inFile;
	inFile.open("student.dat", ios::binary);
	if (!inFile) {
		cout << "File could not be open !! Press Enter...";
		cin.ignore();
		cin.get();
		return;
	}
	bool flag = false;
	while (inFile.read(reinterpret_cast<char*> (&st), sizeof(student)))
	{
		if (st.getIDnum() == n) {
			st.showdata();
			flag = true;
		}
	}
	inFile.close();
	if (flag = true)
		cout << "\n\nRecord do not exist.";
	cin.ignore();
	cin.get();
}

void modify_student(int n) {
	bool found = false;
	student st;
	ifstream File;
	File.open("student.dat", ios::binary | ios::in | ios::out);
	File.seekg(0);
	if (!File) {
		cout << "File could not be open !! Press Enter...";
		cin.ignore();
		cin.get();
		return;
	}
	while (!File.eof() && found == false) {
		File.read(reinterpret_cast<char*> (&st), sizeof(student));
		if (st.getIDnum() == n) {
			st.showdata();
			cout << "\n\nPlease Enter New details of Student" << endl;
			st.getdata();
			int pos = (-1) * static_cast<int>(sizeof(st));
			File.seekg(pos, ios::cur);
			File.read(reinterpret_cast<char *> (&st), sizeof(student));
			cout << "\n\n\t Record Updated";
			found = true;
		}
	}
	File.close();
	if (found == false)
		cout << "\n\n Record Not Found ";
	cin.ignore();
	cin.get();
}
void delete_student(int n) {
	student st;
	ifstream inFile;
	inFile.open("student.dat", ios::binary);
	if (!inFile) {
		cout << "File could not be open !! Press Enter...";
		cin.ignore();
		cin.get();
		return;
	}
	ofstream outFile;
	outFile.open("Temp.dat", ios::out);
	inFile.seekg(0, ios::beg);
	while (inFile.read(reinterpret_cast<char*> (&st), sizeof(student)))
	{
		if (st.getIDnum() != n) {
			outFile.write(reinterpret_cast<char*> (&st), sizeof(student));
		}
	}
	outFile.close();
	inFile.close();
	remove("student.dat");
	rename("Temp.dat", "student.dat");
	cout << "\n\n\tRecord Deleted..";
	cin.ignore();
	cin.get();
}

void class_result() {
	student st;
	ifstream inFile;
	inFile.open("student.dat", ios::binary);
	if (!inFile) {
		cout << "File could not be open !! Press Enter...";
		cin.ignore();
		cin.get();
		return;
	}
	cout << "\n\n\t\t ALL STUDENTS RESULT \n\n";
	cout << "=========================================================================================\n";
	while (inFile.read(reinterpret_cast<char*> (&st), sizeof(student)))
	{
		st.show_tablular();
	}
	cin.ignore();
	cin.get();
	inFile.close();
}
int main()
{
	char choice;
	int number;
	cout.setf(ios::fixed | ios::showpoint);
	cout << setprecision(2);
	do
	{
		cout << "\n\n";
		cout << "\t\t\tSTUDENTS MANAGEMENT SYSTEM";
		cout << "\n\n\t###############################################################";
		cout << "\n\n\t\t\t1. CREATE STUDENT RECORD";
		cout << "\n\n\t\t\t2. DISPLAY ALL STUDENT RECORDS";
		cout << "\n\n\t\t\t3. SEARCH STUDENT RECORD";
		cout << "\n\n\t\t\t4. MODIFY STUDENT RECORD";
		cout << "\n\n\t\t\t5. DELETE STUDENT RECORD";
		cout << "\n\n\t\t\t6. DISPLAY CLASS RESULT";
		cout << "\n\n\t\t\t7. EXIT";
		cout << "\n\n\t###############################################################";
		cout << "\n\n\t\t\tEnter Your Choice(1-7): ";
		cin >> choice;

		switch (choice)
		{
		case'1':write_student(); break;
		case'2':display_all(); break;
		case'3':cout << "\n\n\tEnter Student's ID number: ";
			cin >> number;
			display_sp(number); break;
		case'4':cout << "\n\n\tEnter Student's ID number: ";
			cin >> number;
			modify_student(number); break;
		case'5':cout << "\n\n\tEnter Student's ID number: ";
			cin >> number;
			delete_student(number); break;
		case'6':class_result(); break;
		case'7':exit(0);
		default:cout << "\a";

		}
	} while (choice != '7');
	return 0;
}

